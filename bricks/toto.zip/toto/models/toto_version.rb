class TotoVersion < Version
  def self.content_class
    TotoContent
  end
end