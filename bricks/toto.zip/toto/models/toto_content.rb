class TotoContent < ActiveRecord::Base
  act_as_content
  zafu_readable :toto
end