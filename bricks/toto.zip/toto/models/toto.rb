class Toto < Page
  def self.version_class
    TotoVersion
  end
end