class CreateToto < ActiveRecord::Migration
  def self.up
    create_table "toto_contents", :options => 'type=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci' do |t|
      t.column "created_at", :datetime
      t.column "updated_at", :datetime
      t.column "version_id", :integer
      t.column "toto", :string, :limit => 60, :default => "", :null => false
    end
  end

  def self.down
    drop_table "toto_contents"
  end
end
